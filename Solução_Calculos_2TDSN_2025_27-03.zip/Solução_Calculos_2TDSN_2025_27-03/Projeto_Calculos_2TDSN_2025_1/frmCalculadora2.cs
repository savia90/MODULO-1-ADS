﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Calculos_2TDSN_2025_1
{
    public partial class frmCalculadora2 : Form
    {
        public frmCalculadora2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            decimal a, b, r=0;

            try
            {
                a = decimal.Parse(txtN1.Text);

                b = decimal.Parse(txtN2.Text);

                if (rdbSomar.Checked)
                {
                    r = a + b;
                }
                else if (rdbSubtrair.Checked)
                {
                    r = a - b;
                }
                else if(rdbMultiplicar.Checked)
                {
                    r = a * b;
                }
                else if(rdbPotenciação.Checked)
                {
                    
                }
                else if (rdbDividir.Checked)
                {
                    r = a / b;
                }
                lblResultado.Text = r.ToString();
            }
            catch(FormatException) 
            {
                MessageBox.Show("Informe apenas números");               
            }
            catch(DivideByZeroException)
            {
                MessageBox.Show("Impossível Divisão por zero");       
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtN1.Clear();
            txtN2.Clear();
            lblResultado.Text = "?";
            txtN1.Focus();         
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void txtN1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtN2_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmCalculadora2_Load(object sender, EventArgs e)
        {

        }
    }
}
