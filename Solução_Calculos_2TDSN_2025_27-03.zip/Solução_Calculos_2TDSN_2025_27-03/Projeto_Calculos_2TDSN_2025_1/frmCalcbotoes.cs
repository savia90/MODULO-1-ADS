﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Calculos_2TDSN_2025_1
{
    public partial class frmCalcbotoes : Form
    {
        public frmCalcbotoes()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void frmCalcbotoes_Load(object sender, EventArgs e)
        {

        }

        private void txtN1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtN2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            lblSinal.Text = "+";
            double a, b;
            try
            {

                a = double.Parse(txtN1.Text);
                b = double.Parse(txtN2.Text);

                lblResultado.Text = (a + b).ToString();
            }
            catch (FormatException) //isso tudo serve para que se o usuario escreva letras ao inves de numeros na caixa de entrada
            {
                MessageBox.Show("Favor apenas números", "Erro!!!");
            }
            catch (DivideByZeroException)   //mensagem para "nao é divisivel por zero
            {

            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtN1.Clear();
            txtN2.Clear();
            lblSinal.Text="?"; //as label nao tem a função clear então se troca o texto delas caso queira limpar oque estava escrito antes
            lblResultado.Text="?";
            txtN1.Focus();
            //o .focus envia o foco para textboxNumero1

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //esse é o botão de multiplicar a gente abriu o css sem renomear ele então agora ele é button1
            lblSinal.Text = "-";
            double a, b;
            try
            {

                a = double.Parse(txtN1.Text);
                b = double.Parse(txtN2.Text);

                lblResultado.Text = (a - b).ToString();
            }
            catch (FormatException) //isso tudo serve para que se o usuario escreva letras ao inves de numeros na caixa de entrada
            {
                MessageBox.Show("Favor apenas números", "Erro!!!");
            }
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            lblSinal.Text = "*";
            double a, b;
            try
            {

                a = double.Parse(txtN1.Text);
                b = double.Parse(txtN2.Text);

                lblResultado.Text = (a * b).ToString();
            }
            catch (FormatException) //isso tudo serve para que se o usuario escreva letras ao inves de numeros na caixa de entrada
            {
                MessageBox.Show("Favor apenas números", "Erro!!!");
            }
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            lblSinal.Text = "/";
            decimal a, b;
            try
            {

                a = decimal.Parse(txtN1.Text);
                b = decimal.Parse(txtN2.Text);

                lblResultado.Text = (a / b).ToString();
            }
            catch (FormatException) //isso tudo serve para que se o usuario escreva letras ao inves de numeros na caixa de entrada
            {
                MessageBox.Show("Favor apenas números", "Erro!!!");
            }
            catch (DivideByZeroException)   //mensagem para "nao é divisivel por zero
            {
                MessageBox.Show("Nenhum número pode ser dividido por zero. Só que isso não significa que dividir por zero nos dá o resultado zero. Na verdade, o resultado não existe porque não existe esse tipo de operação.", "Erro!!!");
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
