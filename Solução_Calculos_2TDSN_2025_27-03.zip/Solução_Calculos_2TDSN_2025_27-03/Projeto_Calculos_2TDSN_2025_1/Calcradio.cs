﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Diagnostics.Tracing;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Calculos_2TDSN_2025_1
{
    public partial class Calcradio : Form
    {

        public Calcradio()
        {
            InitializeComponent();
            lblVisor.Text = "";
        }

        private double currentResult = 0;  // Resultado acumulado da operação
        private string operation;
        private string input;
        List<double> values = new List<double>();  // Lista para armazenar os valores
        private double r = 0;
        private bool isNewOperation = true;


        string operacao;
        decimal vNumAnt;
        bool vLimpar = false;


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        

        private void btnDividir_Click(object sender, EventArgs e)
        {

        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {

        }

        private void btnSomar_Click(object sender, EventArgs e)
        {

        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {

        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            decimal vNumAtual = decimal.Parse(lblVisor.Text);
            switch (operacao)
            {
                case "+":
                    lblVisor.Text = (vNumAnt + vNumAtual).ToString();
                    break;
                case "-":
                    lblVisor.Text = (vNumAnt - vNumAtual).ToString();
                    break;
                case "x":
                    lblVisor.Text = (vNumAnt * vNumAtual).ToString();
                    break;
                case "Potencia":
                    lblVisor.Text = Math.Pow((double)vNumAnt, (double)vNumAtual).ToString();
                    break;
                case "/":

                    if (vNumAtual != 0)
                    {
                        lblVisor.Text = (vNumAnt / vNumAtual).ToString();
                    }
                    else
                    {
                        lblVisor.Text = "Erro: Divisão por zero!";
                    }
                    break;
                  
            }
            lblVisor.Focus();
        }


        private void ApplyOperation()
        {
            double currentNumber = double.Parse(input);

            if (isNewOperation)
            {
                currentResult = currentNumber; // Primeiro número
            }
            else
            {
                switch (operation)
                {
                    case "+":
                        currentResult += currentNumber;
                        break;
                    case "-":
                        currentResult -= currentNumber;
                        break;
                    case "*":
                        currentResult *= currentNumber;
                        break;
                    case "/":
                        if (currentNumber != 0)
                        {
                            currentResult /= currentNumber;
                        }
                        else
                        {
                            lblVisor.Text = "Erro: Divisão por zero!";
                            currentResult = 0;
                        }
                        break;
                }
            }

            input = "";  // Limpa o campo de entrada para o próximo número
        }
        //botões
        private void btn0_Click(object sender, EventArgs e)
        {
            input += "0";
            lblVisor.Text = input;
        }
        private void btn1_Click(object sender, EventArgs e)
        {
            input += "1";
            lblVisor.Text = input;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            input += "2";
            lblVisor.Text = input;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            input += "3";
            lblVisor.Text = input;
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            input += "4";
            lblVisor.Text = input;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            input += "5";
            lblVisor.Text = input;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            input += "6";
            lblVisor.Text = input;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            input += "7";
            lblVisor.Text = input;
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            input += "8";
            lblVisor.Text = input;
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            input += "9";
            lblVisor.Text = input;
        }



        private void f_operacoes(object sender, EventArgs e)
        {
            operacao = ((Button)sender).Text;
            vNumAnt = decimal.Parse(lblVisor.Text);
            vLimpar = true;
        }

        private void btnVirgula_Click(object sender, EventArgs e)
        {
            if (!lblVisor.Text.Contains(","))
            {
                lblVisor.Text += ",";
            }
        }

        private void Calcradio_KeyDown(object sender, KeyEventArgs e)
        {
           label1.Text = e.KeyCode.ToString(); 
           string digito = e.KeyCode.ToString();
            Button bot = new Button();
            if (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9)  //D0 é o numero 0 das teclas de cima do teclado
            {
                bot.Text = digito.Substring(1, 1);
                f_numeros(bot, e);
            }
            else if (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9) //NumPad0 é a tecla 0 da parte numerica da direita do teclado
            {
                bot.Text = digito.Substring(6, 1);  //aqui o 6 é pra ele ir para a 6 casa da frase ai o 1 é pra ele pegar 1 informação na casa 6
                f_numeros(bot, e);
            }
            switch (e.KeyCode.ToString())
            {
                case "Add":
                    bot.Text = "+";
                    f_operacoes(bot, e);
                    break;
                case "Subtract":
                    bot.Text = "-";
                    f_operacoes(bot, e);
                    break;
                case "Return":
                    btnIgual_Click(sender, e);
                    break;

            } 
        }
        private void f_numeros(object sender, EventArgs e)
        {
            string digito = ((Button)sender).Text;

            if (vLimpar)
            {
                lblVisor.Text = "";
                vLimpar = false;
            }

            if (lblVisor.Text == "0")
            {
                lblVisor.Text = digito;
            }
            else
            {
                lblVisor.Text += digito;
            }
            lblVisor.Focus();  //para jogar o foco para o visor, para que seja possivel executar contar ao clicar no Enter do teclado (por enquanto essa parte ainda nao foi codificada)
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            //Esse é pra apagar o numero que foi digitado na calculadora 
            lblVisor.Text = lblVisor.Text.Substring(0, lblVisor.Text.Length - 1);
            if (lblVisor.Text == "")
            {
                lblVisor.Text = "0";
            }

        }

        private void lblVisor_Click(object sender, EventArgs e)
        {

        }
    }
}

