﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Calculos_2TDSN_2025_1
{
    public partial class MDI_Menu : Form
    {
        public MDI_Menu()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void comBotõesToolStripMenuItem_Click(object sender, EventArgs e)
        { 
                frmCalcbotoes objCalcBot = new frmCalcbotoes(); //cria o objeto
                objCalcBot.MdiParent = this; //informa que ele vai abrir dentro do mdi
                objCalcBot.Show();          
        }

        private void MDI_Menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(MessageBox.Show("Deseja realmente sair?" , "Saindo..." , MessageBoxButtons.YesNo , MessageBoxIcon.Question , MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                /*Cancelar o Fechamento do Formulario*/
                e.Cancel = true;

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            stlDataHora.Text = DateTime.Now.ToString();
        }

        private void comRadioButtonsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCalculadora2 objFormRadio = new frmCalculadora2();
            objFormRadio.MdiParent = this;
            objFormRadio.Show();
            
        }

        private void visorÚnicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Calcradio objCalcradio = new Calcradio();
            objCalcradio.MdiParent = this;
            objCalcradio.Show();
        }
    }
}
